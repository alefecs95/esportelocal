<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Services\TenantFileService;
use Illuminate\Http\Request;

class UploadController extends Controller
{
    protected $fileService;

    public function __construct(TenantFileService $fileService)
    {
        $this->fileService = $fileService;
    }

    public function store(Request $request)
    {
        $request->validate([
            'image' => 'required|file|image|max:20480', // Max 20MB
        ]);

        try {
            // O storeFile espera: arquivo, pasta_destino
            $path = $this->fileService->storeFile($request->file('image'), 'editor_uploads');
            
            // Storage::url retorna /storage/caminho...
            $url = \Illuminate\Support\Facades\Storage::url($path);
            
            // Força URL completa com domínio
            $url = \Illuminate\Support\Facades\URL::to($url);

            return response()->json([
                'success' => 1,
                'file' => [
                    'url' => $url,
                ]
            ]);
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Log::error('Erro upload editor: ' . $e->getMessage());
            return response()->json([
                'success' => 0,
                'message' => 'Erro ao fazer upload da imagem.'
            ], 500);
        }
    }
}
