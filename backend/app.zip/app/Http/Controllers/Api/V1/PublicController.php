<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Atleta;
use App\Models\Campeonato;
use App\Models\Equipe;
use App\Models\Modalidade;
use App\Models\Partida;
use App\Models\Noticia;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;

class PublicController extends Controller
{
    public function getHomeData()
    {
        // Estatísticas
        $stats = [
            'campeonatos_realizados' => Campeonato::where('status', 'finalizado')->count() + Campeonato::where('status', 'em_andamento')->count(),
            'atletas_cadastrados' => Atleta::count(),
            'equipes_ativas' => Equipe::count(), 
            'modalidades' => Modalidade::count(),
        ];

        // 1. Buscar Partidas
        // Removido 'mandante' e 'visitante' do with() pois são atributos computados (accessors) e não relacionamentos
        $partidas = Partida::with(['fase.campeonato'])
            ->whereIn('status', ['agendada', 'em_andamento'])
            ->whereNotNull('data_jogo')
            ->where('data_jogo', '>=', Carbon::now()->subHours(4))
            ->orderBy('data_jogo', 'asc')
            ->limit(10) // Aumentado limite
            ->get()
            ->map(function ($partida) {
                $data = Carbon::parse($partida->data_jogo);
                $mandanteLogo = $partida->mandante->logo ?? null;
                $visitanteLogo = $partida->visitante->logo ?? null;

                return [
                    'id' => 'p_' . $partida->id, 
                    'tipo' => 'partida',
                    'campeonato' => $partida->fase->campeonato->nome ?? 'Amistoso',
                    'titulo' => $partida->fase->campeonato->nome ?? 'Amistoso', // Frontend usa titulo ou campeonato
                    'subtitulo' => $partida->fase->nome ?? '',
                    'data_iso' => $partida->data_jogo, 
                    'data' => $data->format('d/m'),
                    'hora' => $data->format('H:i'),
                    'local' => $partida->local ?? 'Local a definir',
                    'mandante' => [
                        'nome' => $partida->mandante->nome ?? 'A definir',
                        'logo' => $mandanteLogo ? Storage::url($mandanteLogo) : null,
                    ],
                    'visitante' => [
                        'nome' => $partida->visitante->nome ?? 'A definir',
                        'logo' => $visitanteLogo ? Storage::url($visitanteLogo) : null,
                    ],
                    'imagem_url' => null 
                ];
            });
            
        // 2. Eventos (Lógica mantida mas simplificada para não poluir se não tiver eventos)
        $proximosEventos = $partidas; 

        return response()->json([
            'stats' => $stats,
            'proximos_eventos' => $proximosEventos
        ]);
    }

    public function getPartidas(Request $request)
    {
        $perPage = (int) $request->query('per_page', 12);
        $perPage = max(6, min($perPage, 50));
        $status = $request->query('status');
        $campeonatoId = $request->query('campeonato_id');

        $query = Partida::query()
            ->with(['fase.campeonato'])
            ->whereNotNull('data_jogo')
            ->when($status, function ($q) use ($status) {
                $q->where('status', $status);
            })
            ->when($campeonatoId, function ($q) use ($campeonatoId) {
                $q->whereHas('fase', function ($faseQuery) use ($campeonatoId) {
                    $faseQuery->where('campeonato_id', $campeonatoId);
                });
            })
            ->orderByRaw("case when status = 'em_andamento' then 0 when status = 'agendada' then 1 else 2 end")
            ->orderBy('data_jogo', 'asc');

        $partidas = $query->paginate($perPage);
        $partidas->getCollection()->transform(function ($partida) {
            $partida->append(['mandante', 'visitante']);
            return $partida;
        });

        return response()->json($partidas);
    }

    public function getNoticias(Request $request)
    {
        $perPage = (int) $request->query('per_page', 10);
        $perPage = max(5, min($perPage, 50));
        $query = Noticia::query()
            ->where('publicado', true)
            ->orderByDesc('publicado_em')
            ->orderByDesc('created_at');
        return response()->json($query->paginate($perPage));
    }

    public function getNoticia($id)
    {
        $noticia = Noticia::where('publicado', true)->findOrFail($id);
        return response()->json($noticia);
    }

    public function getArtilharia($id)
    {
        $campeonato = Campeonato::findOrFail($id);
        
        $gols = \DB::table('eventos_partida')
            ->join('partidas', 'eventos_partida.partida_id', '=', 'partidas.id')
            ->join('fases', 'partidas.fase_id', '=', 'fases.id')
            ->join('atletas', 'eventos_partida.jogador_id', '=', 'atletas.id')
            ->join('equipes', 'eventos_partida.time_id', '=', 'equipes.id')
            ->where('fases.campeonato_id', $id)
            ->where('eventos_partida.tipo_evento', 'GOL')
            ->select(
                'atletas.id', 
                'atletas.nome', 
                'atletas.foto', 
                'equipes.nome as equipe_nome', 
                'equipes.logo as equipe_logo', 
                \DB::raw('count(*) as gols')
            )
            ->groupBy('atletas.id', 'atletas.nome', 'atletas.foto', 'equipes.nome', 'equipes.logo')
            ->orderByDesc('gols')
            ->get()
            ->map(function ($item) {
                $item->foto_url = $item->foto ? asset('storage/' . $item->foto) : null;
                $item->equipe_logo_url = $item->equipe_logo ? asset('storage/' . $item->equipe_logo) : null;
                return $item;
            });
            
        return response()->json($gols);
    }

    public function getCartoes($id)
    {
        $campeonato = Campeonato::findOrFail($id);
        $suspensaoAutomaticaAtiva = (bool) ($campeonato->suspensao_automatica_ativa ?? true);
        $cartoesAmarelosParaSuspensao = max(1, (int) ($campeonato->cartoes_amarelos_para_suspensao ?? 2));
        $cartaoVermelhoSuspende = (bool) ($campeonato->cartao_vermelho_suspende ?? true);

        $cartoes = \DB::table('eventos_partida')
            ->join('partidas', 'eventos_partida.partida_id', '=', 'partidas.id')
            ->join('fases', 'partidas.fase_id', '=', 'fases.id')
            ->join('atletas', 'eventos_partida.jogador_id', '=', 'atletas.id')
            ->join('equipes', 'eventos_partida.time_id', '=', 'equipes.id')
            ->where('fases.campeonato_id', $id)
            ->whereIn('eventos_partida.tipo_evento', ['CARTAO_AMARELO', 'CARTAO_VERMELHO'])
            ->select(
                'atletas.id',
                'atletas.nome',
                'atletas.foto',
                'equipes.id as equipe_id',
                'equipes.nome as equipe_nome',
                'equipes.logo as equipe_logo',
                'eventos_partida.tipo_evento',
                'partidas.data_jogo',
                'partidas.id as partida_id'
            )
            ->orderBy('partidas.data_jogo')
            ->get();

        // Processar por jogador
        $ranking = [];
        
        foreach ($cartoes as $cartao) {
            $atletaId = $cartao->id;
            
            if (!isset($ranking[$atletaId])) {
                $ranking[$atletaId] = [
                    'id' => $atletaId,
                    'nome' => $cartao->nome,
                    'foto_url' => $cartao->foto ? asset('storage/' . $cartao->foto) : null,
                    'equipe_nome' => $cartao->equipe_nome,
                    'equipe_logo_url' => $cartao->equipe_logo ? asset('storage/' . $cartao->equipe_logo) : null,
                    'amarelos' => 0,
                    'vermelhos' => 0,
                    'ultimo_cartao_tipo' => null,
                    'ultimo_cartao_partida_id' => null,
                    'equipe_id' => $cartao->equipe_id
                ];
            }
            
            if ($cartao->tipo_evento === 'CARTAO_AMARELO') {
                $ranking[$atletaId]['amarelos']++;
            } else {
                $ranking[$atletaId]['vermelhos']++;
            }
            
            $ranking[$atletaId]['ultimo_cartao_tipo'] = $cartao->tipo_evento;
            $ranking[$atletaId]['ultimo_cartao_partida_id'] = $cartao->partida_id;
        }

        // Calcular status de suspensão
        // Regra: Suspenso se (amarelos % 2 == 0 e amarelos > 0) OU (ultimo foi vermelho)
        // E se a partida do ultimo cartão foi a última partida jogada pela equipe
        
        // Buscar última partida finalizada de cada equipe
        $equipesIds = array_unique(array_column($ranking, 'equipe_id'));
        $ultimasPartidasEquipes = [];
        
        foreach ($equipesIds as $equipeId) {
            $ultimaPartida = Partida::where(function($q) use ($equipeId) {
                    $q->where('mandante_id', $equipeId)
                      ->orWhere('visitante_id', $equipeId);
                })
                ->whereHas('fase', function ($q) use ($id) {
                    $q->where('campeonato_id', $id);
                })
                ->where('status', 'finalizada')
                ->orderByDesc('data_jogo')
                ->first();
                
            if ($ultimaPartida) {
                $ultimasPartidasEquipes[$equipeId] = $ultimaPartida->id;
            }
        }

        foreach ($ranking as &$jogador) {
            $suspenso = false;
            $motivo = '';
            
            $ultimaPartidaEquipe = $ultimasPartidasEquipes[$jogador['equipe_id']] ?? null;
            
            if ($suspensaoAutomaticaAtiva && $ultimaPartidaEquipe && $jogador['ultimo_cartao_partida_id'] == $ultimaPartidaEquipe) {
                if ($cartaoVermelhoSuspende && $jogador['ultimo_cartao_tipo'] === 'CARTAO_VERMELHO') {
                    $suspenso = true;
                    $motivo = 'Vermelho na última partida';
                }
                elseif ($jogador['amarelos'] > 0 && $jogador['amarelos'] % $cartoesAmarelosParaSuspensao == 0) {
                    $suspenso = true;
                    $motivo = "Acúmulo de cartões amarelos ({$cartoesAmarelosParaSuspensao})";
                }
            }
            
            $jogador['suspenso'] = $suspenso;
            $jogador['status_texto'] = $suspenso ? 'Suspenso' : 'Regular';
            $jogador['motivo_suspensao'] = $motivo;
            $jogador['suspensao_automatica_ativa'] = $suspensaoAutomaticaAtiva;
            $jogador['cartoes_amarelos_para_suspensao'] = $cartoesAmarelosParaSuspensao;
            $jogador['cartao_vermelho_suspende'] = $cartaoVermelhoSuspende;
        }

        return response()->json(array_values($ranking));
    }

    public function getEquipes(Request $request)
    {
        $perPage = (int) $request->query('per_page', 12);
        $search = $request->query('search');

        $query = Equipe::query()
            ->with(['entidade', 'campeonato']) // Removido 'modalidade' que não existe diretamente em Equipe
            ->when($search, function ($q) use ($search) {
                $q->where('nome', 'like', "%{$search}%")
                  ->orWhereHas('entidade', function($q2) use ($search) {
                      $q2->where('cidade', 'like', "%{$search}%");
                  });
            })
            ->orderBy('nome');

        return response()->json($query->paginate($perPage));
    }

    public function getEquipeDetalhe($id)
    {
        $equipe = Equipe::with(['entidade.equipes.campeonato', 'campeonato.modalidade', 'atletasAprovados'])->findOrFail($id);

        $historicoCompeticoes = collect();
        if ($equipe->entidade) {
            $historicoCompeticoes = $equipe->entidade->equipes->map(function($e) {
                return [
                    'id' => $e->id,
                    'campeonato_nome' => $e->campeonato->nome ?? 'N/A',
                    'ano' => $e->campeonato?->data_inicio ? \Carbon\Carbon::parse($e->campeonato->data_inicio)->year : null,
                    'colocacao' => $e->colocacao,
                    'modalidade' => $e->campeonato->modalidade->nome ?? 'N/A'
                ];
            });
        }

        // Últimos 5 jogos
        $ultimosJogos = Partida::with(['mandante', 'visitante'])
            ->where(function($q) use ($id) {
                $q->where('mandante_id', $id)
                  ->orWhere('visitante_id', $id);
            })
            ->where('status', 'finalizada')
            ->orderByDesc('data_jogo')
            ->limit(5)
            ->get()
            ->map(function($p) use ($id) {
                $isMandante = $p->mandante_id == $id;
                $adversario = $isMandante ? $p->visitante : $p->mandante;
                
                return [
                    'id' => $p->id,
                    'data' => $p->data_jogo,
                    'adversario_nome' => $adversario->nome ?? 'Desconhecido',
                    'adversario_logo' => $adversario->logo ? asset('storage/' . $adversario->logo) : null,
                    'placar_mandante' => $p->placar_mandante,
                    'placar_visitante' => $p->placar_visitante,
                    'is_mandante' => $isMandante,
                    'resultado' => $isMandante 
                        ? ($p->placar_mandante > $p->placar_visitante ? 'V' : ($p->placar_mandante == $p->placar_visitante ? 'E' : 'D'))
                        : ($p->placar_visitante > $p->placar_mandante ? 'V' : ($p->placar_visitante == $p->placar_mandante ? 'E' : 'D'))
                ];
            });
        
        return response()->json([
            'equipe' => $equipe,
            'historico_competicoes' => $historicoCompeticoes,
            'ultimos_jogos' => $ultimosJogos
        ]);
    }

    public function getAtletas(Request $request)
    {
        $perPage = (int) $request->query('per_page', 12);
        $search = $request->query('search');

        $query = Atleta::query()
            ->when($search, function ($q) use ($search) {
                $q->where('nome', 'like', "%{$search}%");
            })
            ->orderBy('nome');

        return response()->json($query->paginate($perPage));
    }

    public function getAtletaDetalhe($id)
    {
        $atleta = Atleta::with(['equipes.campeonato.modalidade', 'equipes.entidade', 'inscricoes.campeonato.modalidade'])->findOrFail($id);
        
        // Histórico de competições por EQUIPES
        $competicoesEquipes = $atleta->equipes->map(function($e) {
            return [
                'campeonato' => $e->campeonato->nome,
                'modalidade' => $e->campeonato->modalidade->nome ?? 'N/A',
                'ano' => \Carbon\Carbon::parse($e->campeonato->data_inicio)->year,
                'equipe' => $e->entidade->nome ?? $e->nome, // Fallback se não tiver entidade
                'posicao' => $e->colocacao // Posição da equipe no campeonato
            ];
        });

        // Histórico de competições INDIVIDUAIS (Inscrições)
        $competicoesIndividuais = $atleta->inscricoes->map(function($i) {
             return [
                'campeonato' => $i->campeonato->nome,
                'modalidade' => $i->campeonato->modalidade->nome ?? 'N/A',
                'ano' => \Carbon\Carbon::parse($i->campeonato->data_inicio)->year,
                'equipe' => 'Individual',
                'posicao' => $i->colocacao // Posição do atleta
            ];
        });

        // Mesclar e ordenar
        $competicoes = $competicoesEquipes->merge($competicoesIndividuais)->sortByDesc('ano')->values();

        // Estatísticas Gerais (Agregado de todos os eventos)
        $stats = \DB::table('eventos_partida')
            ->where('jogador_id', $id)
            ->selectRaw("
                count(case when tipo_evento = 'GOL' then 1 end) as total_gols,
                count(case when tipo_evento = 'CARTAO_AMARELO' then 1 end) as total_amarelos,
                count(case when tipo_evento = 'CARTAO_VERMELHO' then 1 end) as total_vermelhos
            ")
            ->first();

        // Total de jogos (partidas onde o jogador teve evento ou estava na súmula - aqui simplificando para eventos ou partidas da equipe)
        // O ideal seria ter uma tabela de escalação. Como não temos, vamos usar o número de jogos da equipe onde ele estava inscrito?
        // Ou melhor, contar partidas onde ele teve evento? Não, isso é pouco.
        // Vamos contar partidas das equipes que ele participou (aproximação)
        // Ou criar a tabela 'escalacao' futuramente.
        // Por enquanto, vamos retornar null ou 0 para jogos se não tivermos certeza.
        
        return response()->json([
            'atleta' => $atleta,
            'competicoes' => $competicoes,
            'stats' => $stats
        ]);
    }
}
