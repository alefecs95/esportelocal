<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Atleta;
use App\Http\Requests\StoreAtletaRequest;
use App\Http\Requests\UpdateAtletaRequest;
use App\Models\User;
use App\Scopes\TenantScope;
use App\Services\AtletaService;
use App\Services\WhatsAppNotificationService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

class AtletaController extends Controller
{
    protected $atletaService;

    public function __construct(
        AtletaService $atletaService,
        private WhatsAppNotificationService $whatsAppNotificationService
    ) {
        $this->atletaService = $atletaService;
    }

    private function response(bool $success, string $message, $data = [], int $status = 200): JsonResponse
    {
        return response()->json([
            'success' => $success,
            'message' => $message,
            'data' => $data,
        ], $status);
    }

    public function index(Request $request): JsonResponse
    {
        $perPage = (int) $request->query('per_page', 10);
        $search = $request->query('search');
        $filters = [
            'acesso_ativo' => $this->parseBooleanQuery($request->query('acesso_ativo')),
            'pode_participar_competicoes' => $this->parseBooleanQuery($request->query('pode_participar_competicoes')),
            'cidade' => $request->query('cidade'),
            'local_votacao' => $request->query('local_votacao'),
            'idade_min' => $request->query('idade_min'),
            'idade_max' => $request->query('idade_max'),
        ];
        $atletas = $this->atletaService->getAll($perPage, $search, $filters);
        return $this->response(true, 'Atletas listados com sucesso', $atletas);
    }

    public function updateStatus(Request $request, string $id): JsonResponse
    {
        $user = $request->user();
        if (!$user) {
            return $this->response(false, 'Não autorizado', [], 401);
        }

        $request->validate([
            'acesso_ativo' => 'required|boolean',
            'pode_participar_competicoes' => 'required|boolean',
        ]);

        $atleta = $this->atletaService->find($id);
        if (!$atleta) {
            return $this->response(false, 'Atleta não encontrado', [], 404);
        }

        $acessoAtivo = (bool) $request->boolean('acesso_ativo');
        $podeParticipar = (bool) $request->boolean('pode_participar_competicoes');

        $atleta = $this->atletaService->update((int) $id, [
            'acesso_ativo' => $acessoAtivo,
            'pode_participar_competicoes' => $podeParticipar,
        ]);

        $userAtleta = User::withoutGlobalScope(TenantScope::class)
            ->where('cpf', preg_replace('/[^0-9]/', '', $atleta->cpf))
            ->where('prefeitura_id', $atleta->prefeitura_id)
            ->first();

        if ($userAtleta) {
            $userAtleta->status = $acessoAtivo ? 'ATIVO' : 'INATIVO';
            $userAtleta->save();
        }

        return $this->response(true, 'Status do atleta atualizado com sucesso', $atleta);
    }

    public function store(StoreAtletaRequest $request): JsonResponse
    {
        try {
            $data = $request->validated();
            $receiveNotifications = (bool) ($data['receive_notifications'] ?? false);
            $phoneForNotification = $this->whatsAppNotificationService->normalizePhone($data['telefone'] ?? null);
            unset($data['receive_notifications']);

            if ($receiveNotifications && !$phoneForNotification) {
                return $this->response(
                    false,
                    'Para enviar notificação WhatsApp, informe um telefone válido com DDD.',
                    [],
                    422
                );
            }

            // Processar arquivos
            // Espera-se que o frontend envie:
            // arquivos[0][file] = (binary)
            // arquivos[0][nome] = "Nome do documento"
            
            $arquivos = [];
            if ($request->has('arquivos')) {
                // Se vier como array de objetos (dependendo de como o frontend envia)
                // Vamos iterar manualmente para montar a estrutura correta para o Service
                foreach ($request->file('arquivos') ?? [] as $index => $file) {
                    // O nome pode vir em um array paralelo ou dentro da estrutura se for form-data complexo
                    // Simplificando: vamos assumir que o frontend envia 'nomes_arquivos' como array indexado igual
                    $nome = $request->input("nomes_arquivos.$index") ?? $file->getClientOriginalName();
                    
                    $arquivos[] = [
                        'file' => $file,
                        'nome' => $nome
                    ];
                }
            }
            
            $data['arquivos'] = $arquivos;

            $atleta = $this->atletaService->create($data);
            if ($receiveNotifications) {
                $this->whatsAppNotificationService->notifyUserRegistration($atleta);
            }
            return $this->response(true, 'Cadastro realizado com sucesso. Seu login é seu CPF e sua senha inicial são os 4 últimos dígitos do CPF. No primeiro acesso será obrigatória a troca de senha.', $atleta, 201);
        } catch (\Exception $e) {
            return $this->response(false, 'Erro ao cadastrar atleta: ' . $e->getMessage(), [], 500);
        }
    }

    public function show(string $id): JsonResponse
    {
        $atleta = $this->atletaService->find($id);
        if (!$atleta) {
            return $this->response(false, 'Atleta não encontrado', [], 404);
        }
        return $this->response(true, 'Atleta encontrado com sucesso', $atleta);
    }

    public function update(UpdateAtletaRequest $request, string $id): JsonResponse
    {
        try {
            $data = $request->validated();
            
            $arquivos = [];
            if ($request->has('arquivos')) {
                foreach ($request->file('arquivos') ?? [] as $index => $file) {
                    $nome = $request->input("nomes_arquivos.$index") ?? $file->getClientOriginalName();
                    $arquivos[] = [
                        'file' => $file,
                        'nome' => $nome
                    ];
                }
            }
            $data['arquivos'] = $arquivos;

            $atleta = $this->atletaService->update($id, $data);
            return $this->response(true, 'Atleta atualizado com sucesso', $atleta);
        } catch (\Exception $e) {
            return $this->response(false, 'Erro ao atualizar atleta: ' . $e->getMessage(), [], 500);
        }
    }

    public function destroy(string $id): JsonResponse
    {
        try {
            $this->atletaService->delete($id);
            return $this->response(true, 'Atleta removido com sucesso', []);
        } catch (\Exception $e) {
            return $this->response(false, 'Erro ao remover atleta: ' . $e->getMessage(), [], 500);
        }
    }

    public function consultarCpf(string $cpf): JsonResponse
    {
        try {
            // 0. Verificar se já existe na base local
            // Limpar CPF
            $cpfLimpo = preg_replace('/[^0-9]/', '', $cpf);
            $atletaLocal = Atleta::where('cpf', $cpfLimpo)->first();
            
            if ($atletaLocal) {
                 return $this->response(true, 'Atleta já cadastrado no sistema', $atletaLocal);
            }

            // 1. Consulta CPF na Receita
            $dadosCpf = $this->atletaService->consultarCpf($cpf);
            
            $retornoCpf = $dadosCpf['retorno'] ?? [];
            $cadastro = $retornoCpf['cadastro'] ?? [];
            $receita = $retornoCpf['receita'] ?? [];
            
            $dataNascimento = null;
            // Pega a data bruta
            $dataNascimentoRaw = $cadastro['dataNascimento'] ?? $receita['dataNascimento'] ?? null;
            
            if ($dataNascimentoRaw) {
                try {
                    // Tenta remover a hora se existir (dd/mm/aaaa 00:00:00 ou yyyy-mm-dd 00:00:00)
                    $dataNascimentoOnly = explode(' ', $dataNascimentoRaw)[0];
                    
                    if (strpos($dataNascimentoOnly, '/') !== false) {
                        // Formato d/m/Y
                        $dataNascimento = Carbon::createFromFormat('d/m/Y', $dataNascimentoOnly)->format('Y-m-d');
                    } else {
                        // Formato Y-m-d
                        $dataNascimento = Carbon::createFromFormat('Y-m-d', $dataNascimentoOnly)->format('Y-m-d');
                    }
                } catch (\Exception $e) {
                    Log::error('Erro ao fazer parsing da data de nascimento', ['raw' => $dataNascimentoRaw, 'error' => $e->getMessage()]);  
                    $dataNascimento = null; // Segue sem data se der erro
                }
            }

            // Variáveis necessárias para o retorno
            $nome = $cadastro['nome'] ?? $receita['nomePessoaFisica'] ?? '';
            $nomeMae = $cadastro['nomeMae'] ?? '';
            
            // Normalização do Sexo
            $sexoRaw = $cadastro['sexo'] ?? '';
            $sexo = '';
            
            if ($sexoRaw) {
                $sexoUpper = strtoupper($sexoRaw);
                if (in_array($sexoUpper, ['M', 'MASCULINO'])) {
                    $sexo = 'MASCULINO';
                } elseif (in_array($sexoUpper, ['F', 'FEMININO'])) {
                    $sexo = 'FEMININO';
                } else {
                    $sexo = 'OUTRO'; // Ou deixar vazio se preferir
                }
            }
            
            Log::info('Consulta CPF realizada', ['cpf' => $cpf, 'sexo_raw' => $sexoRaw, 'sexo_normalized' => $sexo]);

            $mapeado = [
                'nome' => $nome,
                'cpf' => $cadastro['cpf'] ?? $receita['numeroCPF'] ?? $cpf,
                'data_nascimento' => $dataNascimento,
                'sexo' => $sexo,
                'nome_mae' => $nomeMae,
                // Os demais campos retornam vazios para serem preenchidos posteriormente
                'nome_pai' => '', 
                'cep' => '', // Endereço será preenchido pelo ViaCEP no frontend
                'endereco' => '',
                'bairro' => '',
                'cidade' => '',
                'estado' => '',
                'telefone' => '',
                'email' => '',
                'titulo_eleitor' => '',
                'zona_eleitoral' => '',
                'secao_eleitoral' => '',
            ];

            return $this->response(true, 'Dados consultados com sucesso', $mapeado);

        } catch (\Exception $e) {
             return $this->response(false, 'Erro ao consultar CPF: ' . $e->getMessage(), [], 500);
        }
    }

    public function consultarTitulo(Request $request): JsonResponse
    {
        try {
            $dados = $request->all();
            Log::info('Iniciando consulta de Título no Controller', ['dados' => $dados]);
            
            $resultado = $this->atletaService->consultarTitulo($dados);
            
            Log::info('Resultado da consulta de Título', ['resultado' => $resultado]);

            return $this->response(true, 'Consulta realizada com sucesso', $resultado);
        } catch (\Exception $e) {
            Log::error('Erro ao consultar Título no Controller: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
            return $this->response(false, 'Erro ao consultar Título: ' . $e->getMessage(), [], 500);
        }
    }

    private function parseBooleanQuery($value): ?bool
    {
        if ($value === null || $value === '') {
            return null;
        }

        if (in_array($value, [true, 'true', '1', 1, 'ATIVO', 'ativo'], true)) {
            return true;
        }

        if (in_array($value, [false, 'false', '0', 0, 'INATIVO', 'inativo'], true)) {
            return false;
        }

        return null;
    }
}
