<?php

namespace App\Services;

use App\Repositories\AtletaRepository;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use App\Models\Atleta;
use App\Models\User;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Services\TenantFileService;
use Exception;

class AtletaService
{
    protected $atletaRepository;
    protected $fileService;

    public function __construct(AtletaRepository $atletaRepository, TenantFileService $fileService)
    {
        $this->atletaRepository = $atletaRepository;
        $this->fileService = $fileService;
    }

    public function getAll(int $perPage = 10, ?string $search = null, array $filters = []): LengthAwarePaginator
    {
        return $this->atletaRepository->getAll($perPage, $search, $filters);
    }

    public function create(array $data): Atleta
    {
        DB::beginTransaction();
        try {
            $atleta = $this->atletaRepository->create($data);
            
            if (isset($data['arquivos']) && is_array($data['arquivos'])) {
                $this->uploadArquivos($atleta, $data['arquivos']);
            }

            if (isset($data['modalidades']) && is_array($data['modalidades'])) {
                $atleta->modalidades()->sync($data['modalidades']);
            }

            // Criar usuário automaticamente
            $this->criarUsuarioParaAtleta($atleta->cpf, $atleta->nome);

            DB::commit();

            return $atleta->load(['arquivos', 'modalidades']);
        } catch (Exception $e) {
            DB::rollBack();
            throw $e;
        }
    }

    public function criarUsuarioParaAtleta(string $cpf, string $nome): int
    {
        // Limpar CPF (apenas números)
        $cpfLimpo = preg_replace('/[^0-9]/', '', $cpf);

        // Validar se já existe usuário com esse CPF
        if (User::where('cpf', $cpfLimpo)->exists()) {
            throw new Exception("Usuário já cadastrado para este CPF.");
        }

        // Extrair últimos 4 dígitos para senha
        $senha = substr($cpfLimpo, -4);

        // Criar usuário
        $user = User::create([
            'name' => $nome,
            'cpf' => $cpfLimpo,
            'password' => Hash::make($senha),
            'perfil' => 'ATLETA',
            'status' => 'ATIVO',
            'forcar_troca_senha' => true,
            // email será null
        ]);

        return $user->id;
    }

    public function find(int $id): ?Atleta
    {
        $atleta = $this->atletaRepository->find($id);
        if ($atleta) {
            $atleta->load(['arquivos', 'modalidades']);
        }
        return $atleta;
    }

    public function update(int $id, array $data): Atleta
    {
        $atleta = $this->atletaRepository->find($id);
        if (!$atleta) {
            throw new Exception("Atleta não encontrado.");
        }
        
        $this->atletaRepository->update($atleta, $data);

        if (isset($data['arquivos']) && is_array($data['arquivos'])) {
            $this->uploadArquivos($atleta, $data['arquivos']);
        }

        if (isset($data['modalidades']) && is_array($data['modalidades'])) {
            $atleta->modalidades()->sync($data['modalidades']);
        }

        return $atleta->load(['arquivos', 'modalidades']);
    }

    protected function uploadArquivos(Atleta $atleta, array $arquivos)
    {
        foreach ($arquivos as $arquivoData) {
            // $arquivoData deve conter 'file' (UploadedFile) e 'nome' (string)
            if (isset($arquivoData['file']) && $arquivoData['file'] instanceof \Illuminate\Http\UploadedFile) {
                $file = $arquivoData['file'];
                $nome = $arquivoData['nome'] ?? $file->getClientOriginalName();
                
                // Usa o TenantFileService para salvar no contexto do tenant
                $path = $this->fileService->storeFile($file, 'atletas/' . $atleta->id);

                $atleta->arquivos()->create([
                    'nome' => $nome,
                    'path' => $path,
                    'tipo' => $file->getMimeType(),
                ]);
            }
        }
    }

    public function delete(int $id): bool
    {
        $atleta = $this->atletaRepository->find($id);
        if (!$atleta) {
            throw new Exception("Atleta não encontrado.");
        }
        return $this->atletaRepository->delete($atleta);
    }

    public function consultarCpf(string $cpf)
    {
        $url = env('DIRECTD_API_URL');
        $token = env('DIRECTD_API_TOKEN');

        if (!$url || !$token) {
            throw new Exception("API URL ou Token não configurados.");
        }

        // Remover caracteres não numéricos do CPF
        $cpfLimpo = preg_replace('/[^0-9]/', '', $cpf);
        
        // Log para debug
        Log::info("Consultando CPF na API externa", ['url' => $url, 'cpf' => $cpfLimpo]);

        try {
            $response = Http::timeout(10)->get($url, [
                'CPF' => $cpfLimpo,
                'Token' => $token
            ]);
    
            if ($response->successful()) {
                $data = $response->json();
                
                // Verificar se a API retornou erro lógico (ex: CPF inválido, não encontrado)
                Log::info("Retorno API CPF", ['status' => $response->status(), 'data' => $data]);
                
                return $data;
            }
    
            Log::error("Erro API CPF", ['status' => $response->status(), 'body' => $response->body()]);
            // Se falhar a API real, tentar fallback local se estiver em dev
            if (env('APP_ENV') === 'local') {
                 throw new Exception("Falha na API, tentando fallback.");
            }
            throw new Exception("Erro na API externa: " . $response->status() . " - " . $response->body());

        } catch (\Exception $e) {
            Log::error("Exceção ao consultar CPF", ['message' => $e->getMessage()]);
            
            // Fallback para ambiente local para não travar o desenvolvimento
            if (env('APP_ENV') === 'local') {
                Log::warning("Usando dados mockados para CPF {$cpfLimpo}");
                
                // Simular estrutura de resposta da API
                return [
                    'retorno' => [
                        'receita' => [
                            'numeroCPF' => $cpfLimpo,
                            'nomePessoaFisica' => 'ATLETA TESTE ' . substr($cpfLimpo, 0, 3),
                            'dataNascimento' => '01/01/2000',
                            'situacaoCadastral' => 'REGULAR'
                        ]
                    ]
                ];
            }
            throw $e;
        }
    }

    public function consultarTitulo(array $dados)
    {
        $url = env('DIRECTD_API_TSE_URL');
        $token = env('DIRECTD_API_TOKEN');

        if (!$url || !$token) {
            throw new Exception("API URL do TSE ou Token não configurados.");
        }

        // Formatar data para o formato esperado pela API (dd/mm/aaaa)
        $dataNascimento = $dados['data_nascimento']; 
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $dataNascimento)) {
             $dataNascimento = date('d/m/Y', strtotime($dataNascimento));
        } else if (strpos($dataNascimento, ' ') !== false) {
             $dataNascimento = explode(' ', $dataNascimento)[0];
        }

        // Ajuste conforme solicitação do usuário:
        // A consulta deve priorizar NOME, DATA DE NASCIMENTO e NOME DA MÃE.
        // CPF e Título podem ir vazios se não estiverem disponíveis.
        
        $params = [
            'Nome' => $dados['nome'] ?? '',
            'DataNascimento' => $dataNascimento ?? '',
            'NomeMae' => $dados['nome_mae'] ?? '',
            'Token' => $token
        ];

        Log::info('Consultando TSE', ['url' => $url, 'params' => $params]);

        try {
            $response = Http::get($url, $params);
            
            Log::info('Resposta TSE', ['status' => $response->status(), 'body' => $response->body()]);

            if ($response->successful()) {
                return $response->json();
            }
            
            return ['error' => 'Erro na API externa: ' . $response->status() . ' - ' . $response->body()];

        } catch (\Exception $e) {
            Log::error('Erro na requisição TSE: ' . $e->getMessage());
            return ['error' => 'Erro de conexão: ' . $e->getMessage()];
        }
    }
}
