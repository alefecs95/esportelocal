<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\BelongsToTenant;

class Equipe extends Model
{
    use HasFactory, SoftDeletes, BelongsToTenant;

    protected $fillable = [
        'prefeitura_id',
        'user_id',
        'campeonato_id',
        'entidade_id',
        'nome',
        'logo',
        'responsavel',
        'contato',
        'colocacao',
        'status',
        'status_inscricao',
    ];

    protected $appends = ['logo_url'];

    public function getLogoUrlAttribute()
    {
        return $this->logo ? asset('storage/' . $this->logo) : null;
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function campeonato()
    {
        return $this->belongsTo(Campeonato::class);
    }

    public function entidade()
    {
        return $this->belongsTo(Entidade::class);
    }

    public function atletas()
    {
        return $this->belongsToMany(Atleta::class, 'equipe_atleta')
            ->withPivot(['status', 'aprovado_por', 'aprovado_em'])
            ->withTimestamps();
    }

    public function atletasAprovados()
    {
        return $this->belongsToMany(Atleta::class, 'equipe_atleta')
            ->wherePivot('status', 'aprovado')
            ->withPivot(['status', 'aprovado_por', 'aprovado_em'])
            ->withTimestamps();
    }
}
