<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\BelongsToTenant;

class Atleta extends Model
{
    use HasFactory, SoftDeletes, BelongsToTenant;

    protected $fillable = [
        'prefeitura_id',
        'nome',
        'cpf',
        'data_nascimento',
        'sexo',
        'nome_mae',
        'nome_pai',
        'titulo_eleitor',
        'zona_eleitoral',
        'secao_eleitoral',
        'local_votacao',
        'endereco_eleitoral',
        'numero_eleitoral',
        'bairro_eleitoral',
        'cidade_eleitoral',
        'uf_eleitoral',
        'cep',
        'endereco',
        'numero',
        'complemento',
        'bairro',
        'cidade',
        'estado',
        'telefone',
        'email',
        'foto',
        'acesso_ativo',
        'pode_participar_competicoes',
    ];

    protected $casts = [
        'data_nascimento' => 'date',
        'acesso_ativo' => 'boolean',
        'pode_participar_competicoes' => 'boolean',
    ];

    protected $appends = ['foto_url'];

    public function getFotoUrlAttribute()
    {
        return $this->foto ? asset('storage/' . $this->foto) : null;
    }

    public function arquivos()
    {
        return $this->hasMany(AtletaArquivo::class);
    }

    public function modalidades()
    {
        return $this->belongsToMany(Modalidade::class, 'atleta_modalidade');
    }

    public function equipes()
    {
        return $this->belongsToMany(Equipe::class, 'equipe_atleta');
    }

    public function inscricoes()
    {
        return $this->hasMany(Inscricao::class);
    }
}
