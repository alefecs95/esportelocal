<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\URL;

class AtletaArquivo extends Model
{
    use HasFactory;

    protected $fillable = ['atleta_id', 'nome', 'path', 'tipo'];

    protected $appends = ['url'];

    public function atleta()
    {
        return $this->belongsTo(Atleta::class);
    }

    public function getUrlAttribute()
    {
        // Se path for nulo, retornar nulo ou placeholder
        if (!$this->path) return null;

        // Se o path já for uma URL completa (ex: S3 ou URL externa), retorna ela
        if (filter_var($this->path, FILTER_VALIDATE_URL)) {
            return $this->path;
        }

        return URL::to(Storage::url($this->path));
    }
}
