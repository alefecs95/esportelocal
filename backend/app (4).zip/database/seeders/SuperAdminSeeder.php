<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class SuperAdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $user = User::firstOrCreate(
            ['email' => 'superadmin@esportelocal.com'],
            [
                'name' => 'Super Administrador',
                'password' => Hash::make('senha123'),
                'perfil' => 'SUPER_ADMIN',
                'cpf' => '11111111111',
                'status' => 'ATIVO',
                'forcar_troca_senha' => false,
                'prefeitura_id' => null,
            ]
        );

        // Ensure it's correctly set if it already existed
        $user->update([
            'perfil' => 'SUPER_ADMIN',
            'forcar_troca_senha' => false,
            'prefeitura_id' => null,
        ]);
    }
}
