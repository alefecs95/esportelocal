<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <style>
        @page {
            margin: 1cm;
        }
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            color: #333;
        }
        .header {
            text-align: center;
            border-bottom: 2px solid #000;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        .header h1 {
            margin: 0;
            font-size: 18px;
            text-transform: uppercase;
        }
        .header h2 {
            margin: 5px 0;
            font-size: 14px;
            font-weight: normal;
        }
        .info-table {
            width: 100%;
            margin-bottom: 20px;
            border-collapse: collapse;
        }
        .info-table td {
            padding: 5px;
            border: 1px solid #ddd;
        }
        .teams-container {
            width: 100%;
            margin-bottom: 20px;
        }
        .team-box {
            width: 48%;
            float: left;
        }
        .team-box.right {
            float: right;
        }
        .team-header {
            background-color: #eee;
            padding: 5px;
            font-weight: bold;
            text-align: center;
            border: 1px solid #000;
        }
        .player-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 10px;
        }
        .player-table th, .player-table td {
            border: 1px solid #ccc;
            padding: 4px;
        }
        .player-table th {
            background-color: #f9f9f9;
        }
        .footer-signatures {
            margin-top: 50px;
            width: 100%;
            text-align: center;
        }
        .signature-box {
            display: inline-block;
            width: 30%;
            border-top: 1px solid #000;
            margin: 0 10px;
            padding-top: 5px;
        }
        .score-box {
            font-size: 24px;
            font-weight: bold;
            text-align: center;
            padding: 10px;
            border: 2px solid #000;
            margin: 20px 0;
            width: 150px;
            margin-left: auto;
            margin-right: auto;
        }
        .clearfix::after {
            content: "";
            clear: both;
            display: table;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Súmula de Partida</h1>
        <h2><?php echo e($campeonato->nome); ?> - <?php echo e($partida->fase->nome); ?></h2>
    </div>

    <table class="info-table">
        <tr>
            <td><strong>Data/Hora:</strong> <?php echo e($data_jogo); ?></td>
            <td><strong>Local:</strong> <?php echo e($partida->local); ?></td>
            <td><strong>Rodada:</strong> <?php echo e($partida->rodada); ?>ª</td>
        </tr>
        <tr>
            <td colspan="3"><strong>Árbitro:</strong> <?php echo e($partida->arbitro ? $partida->arbitro->name : 'Não designado'); ?></td>
        </tr>
    </table>

    <div class="score-box">
        <?php echo e($partida->placar_mandante ?? ' '); ?> X <?php echo e($partida->placar_visitante ?? ' '); ?>

    </div>

    <div class="teams-container clearfix">
        <!-- Mandante -->
        <div class="team-box">
            <div class="team-header"><?php echo e($partida->mandante_equipe ? $partida->mandante_equipe->nome : 'Mandante'); ?></div>
            <table class="player-table">
                <thead>
                    <tr>
                        <th width="10%">Nº</th>
                        <th>Nome do Atleta</th>
                        <th width="15%">Doc</th>
                        <th width="10%">Gol</th>
                        <th width="10%">CA</th>
                        <th width="10%">CV</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($partida->mandante_equipe && $partida->mandante_equipe->atletas): ?>
                        <?php $__currentLoopData = $partida->mandante_equipe->atletas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atleta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td> <!-- Número da camisa manual -->
                            <td><?php echo e(Str::limit($atleta->nome, 20)); ?></td>
                            <td><?php echo e(Str::limit($atleta->cpf, 11)); ?></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- Linhas extras para reservas/completar -->
                        <?php for($i = 0; $i < (20 - $partida->mandante_equipe->atletas->count()); $i++): ?>
                        <tr>
                            <td>&nbsp;</td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <?php endfor; ?>
                    <?php else: ?>
                        <tr><td colspan="6" style="text-align:center">Sem atletas cadastrados</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <div style="margin-top:10px; border:1px solid #ccc; height:40px; padding:5px;">
                <strong>Técnico:</strong>
            </div>
        </div>

        <!-- Visitante -->
        <div class="team-box right">
            <div class="team-header"><?php echo e($partida->visitante_equipe ? $partida->visitante_equipe->nome : 'Visitante'); ?></div>
            <table class="player-table">
                <thead>
                    <tr>
                        <th width="10%">Nº</th>
                        <th>Nome do Atleta</th>
                        <th width="15%">Doc</th>
                        <th width="10%">Gol</th>
                        <th width="10%">CA</th>
                        <th width="10%">CV</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($partida->visitante_equipe && $partida->visitante_equipe->atletas): ?>
                        <?php $__currentLoopData = $partida->visitante_equipe->atletas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atleta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td><?php echo e(Str::limit($atleta->nome, 20)); ?></td>
                            <td><?php echo e(Str::limit($atleta->cpf, 11)); ?></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php for($i = 0; $i < (20 - $partida->visitante_equipe->atletas->count()); $i++): ?>
                        <tr>
                            <td>&nbsp;</td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <?php endfor; ?>
                    <?php else: ?>
                        <tr><td colspan="6" style="text-align:center">Sem atletas cadastrados</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <div style="margin-top:10px; border:1px solid #ccc; height:40px; padding:5px;">
                <strong>Técnico:</strong>
            </div>
        </div>
    </div>

    <div style="border: 1px solid #000; padding: 10px; margin-top: 20px; height: 80px;">
        <strong>Observações do Árbitro:</strong>
    </div>

    <div class="footer-signatures">
        <div class="signature-box"> Capitão Mandante </div>
        <div class="signature-box"> Árbitro </div>
        <div class="signature-box"> Capitão Visitante </div>
    </div>
</body>
</html>
<?php /**PATH C:\Users\alefe\Documents\trae_projects\SEMEL\backend\resources\views\pdf\sumula.blade.php ENDPATH**/ ?>