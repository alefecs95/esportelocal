<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <style>
        @page {
            margin: 0;
            padding: 0;
        }
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            background-color: #f8f9fa;
        }
        .card-container {
            width: 100%;
            height: 100%;
            position: relative;
            background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%);
            color: white;
            padding: 10px;
            box-sizing: border-box;
            border-radius: 8px; /* Visual only, print might cut */
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid rgba(255,255,255,0.3);
            padding-bottom: 5px;
            margin-bottom: 5px;
        }
        .logo {
            font-size: 10px;
            font-weight: bold;
            text-transform: uppercase;
        }
        .title {
            font-size: 8px;
            text-align: right;
            opacity: 0.9;
        }
        .content {
            display: table;
            width: 100%;
        }
        .photo-area {
            display: table-cell;
            width: 60px;
            vertical-align: top;
        }
        .photo-box {
            width: 55px;
            height: 70px;
            background-color: #ddd;
            border: 2px solid white;
            border-radius: 4px;
            overflow: hidden;
        }
        .photo-box img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .info-area {
            display: table-cell;
            vertical-align: top;
            padding-left: 8px;
        }
        .label {
            font-size: 6px;
            text-transform: uppercase;
            color: rgba(255,255,255,0.7);
            margin-top: 2px;
        }
        .value {
            font-size: 9px;
            font-weight: bold;
            margin-bottom: 2px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            max-width: 150px;
        }
        .footer {
            position: absolute;
            bottom: 5px;
            left: 10px;
            right: 10px;
            font-size: 6px;
            text-align: center;
            border-top: 1px solid rgba(255,255,255,0.3);
            padding-top: 2px;
        }
        .team-badge {
            position: absolute;
            right: 10px;
            bottom: 20px;
            text-align: right;
        }
        .team-name {
            font-size: 8px;
            font-weight: bold;
            background: rgba(255,255,255,0.2);
            padding: 2px 5px;
            border-radius: 3px;
        }
    </style>
</head>
<body>
    <div class="card-container">
        <div class="header">
            <div class="logo">SEMEL</div>
            <div class="title"><?php echo e(Str::limit($campeonato->nome, 30)); ?></div>
        </div>
        
        <div class="content">
            <div class="photo-area">
                <div class="photo-box">
                    <?php if($atleta->arquivos->where('tipo', 'foto')->first()): ?>
                        <!-- Ajustar path para storage link se necessário -->
                         <img src="<?php echo e(storage_path('app/public/' . $atleta->arquivos->where('tipo', 'foto')->first()->path)); ?>" alt="Foto">
                    <?php else: ?>
                        <div style="width:100%; height:100%; display:flex; align-items:center; justify-content:center; color:#555; font-size:20px; text-align:center; padding-top:20px;">
                            ?
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="info-area">
                <div class="label">Nome do Atleta</div>
                <div class="value"><?php echo e(Str::upper($atleta->nome)); ?></div>
                
                <div class="label">CPF</div>
                <div class="value"><?php echo e($atleta->cpf); ?></div>
                
                <div class="label">Data Nasc.</div>
                <div class="value"><?php echo e(\Carbon\Carbon::parse($atleta->data_nascimento)->format('d/m/Y')); ?></div>
            </div>
        </div>

        <div class="team-badge">
            <div class="label" style="text-align:right">Equipe</div>
            <div class="team-name"><?php echo e($equipe ? $equipe->nome : 'SEM EQUIPE'); ?></div>
        </div>

        <div class="footer">
            Válido até: <?php echo e($validade); ?> • Emitido em: <?php echo e($data_emissao); ?>

        </div>
    </div>
</body>
</html>
<?php /**PATH C:\Users\alefe\Documents\trae_projects\SEMEL\backend\resources\views\pdf\carteirinha.blade.php ENDPATH**/ ?>