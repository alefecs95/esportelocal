<?php

namespace App\Http\Controllers;

use App\Models\Atleta;
use App\Models\Partida;
use App\Models\Inscricao;
use App\Models\Equipe;
use App\Models\PartidaEscalacao;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\URL;

use App\Models\Campeonato;

class PdfController extends Controller
{
    // Métodos para gerar URLs assinadas (API)
    public function getUrlListaInscritos($campeonatoId)
    {
        // Verifica se o usuário tem permissão para ver este campeonato (policy ou scope já cuida)
        $campeonato = Campeonato::findOrFail($campeonatoId);
        
        $url = URL::signedRoute('pdf.participantes', ['campeonatoId' => $campeonato->id], Carbon::now()->addMinutes(30));
        
        return response()->json(['url' => $url]);
    }

    public function getUrlCarteirinha($atletaId, $campeonatoId)
    {
        $atleta = Atleta::findOrFail($atletaId);
        // Verifica se usuário pode ver este atleta
        
        $url = URL::signedRoute('pdf.carteirinha', [
            'atletaId' => $atleta->id, 
            'campeonatoId' => $campeonatoId
        ], Carbon::now()->addMinutes(30));
        
        return response()->json(['url' => $url]);
    }

    public function getUrlSumula($partidaId)
    {
        $partida = Partida::findOrFail($partidaId);
        
        $url = URL::signedRoute('pdf.sumula', ['partidaId' => $partida->id], Carbon::now()->addMinutes(60)); // Súmula pode demorar mais
        
        return response()->json(['url' => $url]);
    }


    // Métodos de Geração de PDF (Protegidos por Signed URL)
    public function gerarListaInscritos(Request $request, $campeonatoId)
    {
        if (! $request->hasValidSignature()) {
            abort(403, 'Link expirado ou inválido.');
        }

        $campeonato = Campeonato::findOrFail($campeonatoId);
        
        $inscricoes = Inscricao::with(['atleta', 'categoria', 'atleta.equipes' => function($q) use ($campeonatoId) {
                // Filter teams for this championship only
                $q->where('campeonato_id', $campeonatoId); 
            }])
            ->where('campeonato_id', $campeonatoId)
            ->get();

        // Group by Category Name
        $inscricoesPorCategoria = $inscricoes->groupBy(function($item) {
            return $item->categoria ? $item->categoria->nome : 'Geral';
        })->sortKeys();

        $data = [
            'campeonato' => $campeonato,
            'inscricoesPorCategoria' => $inscricoesPorCategoria,
            'total' => $inscricoes->count(),
            'data_emissao' => Carbon::now()->format('d/m/Y H:i'),
        ];

        $pdf = Pdf::loadView('pdf.lista_inscritos', $data);
        return $pdf->stream("participantes_{$campeonato->id}.pdf");
    }

    public function gerarCarteirinha(Request $request, $atletaId, $campeonatoId)
    {
        if (! $request->hasValidSignature()) {
            abort(403, 'Link expirado ou inválido.');
        }

        // Buscar atleta e verificar inscrição no campeonato
        $inscricao = Inscricao::with(['atleta', 'campeonato', 'atleta.equipes' => function($q) use ($campeonatoId) {
            $q->where('campeonato_id', $campeonatoId);
        }])
        ->where('atleta_id', $atletaId)
        ->where('campeonato_id', $campeonatoId)
        ->firstOrFail();

        $atleta = $inscricao->atleta;
        $campeonato = $inscricao->campeonato;
        $equipe = $atleta->equipes->first(); // Equipe neste campeonato

        $data = [
            'atleta' => $atleta,
            'campeonato' => $campeonato,
            'equipe' => $equipe,
            'validade' => Carbon::parse($campeonato->data_fim)->format('d/m/Y'),
            'data_emissao' => Carbon::now()->format('d/m/Y'),
        ];

        $pdf = Pdf::loadView('pdf.carteirinha', $data);
        
        // Formato cartão de crédito aprox: 85.6mm x 53.98mm
        $pdf->setPaper([0, 0, 242.64, 153.07], 'landscape'); 

        return $pdf->stream("carteirinha_{$atleta->id}.pdf");
    }

    public function gerarSumula(Request $request, $partidaId)
    {
        if (! $request->hasValidSignature()) {
            abort(403, 'Link expirado ou inválido.');
        }

        $partida = Partida::with([
            'fase.campeonato',
            'arbitro' // User
        ])->findOrFail($partidaId);

        $escalacoesPorEquipe = PartidaEscalacao::with('atleta')
            ->where('partida_id', $partida->id)
            ->get()
            ->groupBy('equipe_id');

        $montarAtletasParaPdf = function (?Equipe $equipe, int $equipeId) use ($escalacoesPorEquipe) {
            if (!$equipe) {
                return collect();
            }

            $escalacoesEquipe = collect($escalacoesPorEquipe->get($equipeId, []))
                ->sortBy([
                    ['titular', 'desc'],
                    ['ordem', 'asc'],
                ])
                ->values();

            if ($escalacoesEquipe->isEmpty()) {
                return $equipe->atletasAprovados->map(function ($atleta) {
                    $atleta->setAttribute('escala_tipo', '');
                    $atleta->setAttribute('escala_capitao', false);
                    return $atleta;
                })->values();
            }

            return $escalacoesEquipe
                ->map(function ($esc) {
                    if (!$esc->atleta) {
                        return null;
                    }
                    $esc->atleta->setAttribute('escala_tipo', $esc->titular ? 'TIT' : 'RES');
                    $esc->atleta->setAttribute('escala_capitao', (bool) $esc->capitao);
                    return $esc->atleta;
                })
                ->filter()
                ->values();
        };

        $partida->mandante_equipe = Equipe::with(['atletasAprovados' => function($q) {
            $q->orderBy('nome');
        }])->find($partida->mandante_id);
        if ($partida->mandante_equipe) {
            $partida->mandante_equipe->setRelation('atletas', $montarAtletasParaPdf($partida->mandante_equipe, (int) $partida->mandante_id));
        }

        $partida->visitante_equipe = Equipe::with(['atletasAprovados' => function($q) {
            $q->orderBy('nome');
        }])->find($partida->visitante_id);
        if ($partida->visitante_equipe) {
            $partida->visitante_equipe->setRelation('atletas', $montarAtletasParaPdf($partida->visitante_equipe, (int) $partida->visitante_id));
        }

        $data = [
            'partida' => $partida,
            'campeonato' => $partida->fase->campeonato,
            'data_jogo' => $partida->data_jogo ? Carbon::parse($partida->data_jogo)->format('d/m/Y H:i') : 'A definir',
        ];

        $pdf = Pdf::loadView('pdf.sumula', $data);
        return $pdf->stream("sumula_partida_{$partida->id}.pdf");
    }

    public function gerarFichaAtleta(Request $request, $atletaId)
    {
        $atleta = Atleta::with(['modalidades', 'arquivos', 'prefeitura'])->findOrFail($atletaId);
        $instituicao = $atleta->prefeitura;

        if (!$instituicao && App::has('current_tenant')) {
            $instituicao = App::get('current_tenant');
        }

        $instituicaoLogo = null;
        if ($instituicao && !empty($instituicao->logo)) {
            if (filter_var($instituicao->logo, FILTER_VALIDATE_URL)) {
                $instituicaoLogo = $instituicao->logo;
            } else {
                $logoPath = storage_path('app/public/' . ltrim($instituicao->logo, '/'));
                if (file_exists($logoPath)) {
                    $instituicaoLogo = $logoPath;
                }
            }
        }

        $fotoAtleta = null;
        if (!empty($atleta->foto)) {
            $fotoPath = storage_path('app/public/' . ltrim($atleta->foto, '/'));
            if (file_exists($fotoPath)) {
                $fotoAtleta = $fotoPath;
            }
        }

        if (!$fotoAtleta) {
            $arquivoFoto = $atleta->arquivos
                ->first(function ($arquivo) {
                    return str_contains((string) $arquivo->tipo, 'image') || strtolower((string) $arquivo->tipo) === 'foto';
                });

            if ($arquivoFoto && !empty($arquivoFoto->path)) {
                $fotoPath = storage_path('app/public/' . ltrim($arquivoFoto->path, '/'));
                if (file_exists($fotoPath)) {
                    $fotoAtleta = $fotoPath;
                }
            }
        }

        $data = [
            'instituicao' => $instituicao,
            'instituicao_logo' => $instituicaoLogo,
            'atleta' => $atleta,
            'foto_atleta' => $fotoAtleta,
            'data_emissao' => Carbon::now()->format('d/m/Y H:i'),
        ];

        $pdf = Pdf::loadView('pdf.ficha_atleta', $data);
        $pdf->setPaper('a4', 'portrait');

        return $pdf->download("ficha_atleta_{$atleta->id}.pdf");
    }
}
