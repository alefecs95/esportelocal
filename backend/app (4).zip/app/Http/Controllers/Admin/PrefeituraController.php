<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Prefeitura;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;
use Illuminate\Support\Str;
use App\Services\TenantFileService;

class PrefeituraController extends Controller
{
    protected $fileService;

    public function __construct(TenantFileService $fileService)
    {
        $this->fileService = $fileService;
    }

    public function index()
    {
        $q = request()->query('q');
        
        // Se passar per_page=-1, traz tudo (dentro de um limite razoável ou total)
        $perPage = request()->query('per_page');

        $query = Prefeitura::query();

        if ($q) {
            $query->where(function($builder) use ($q) {
                $builder->where('nome', 'like', "%{$q}%")
                        ->orWhere('slug', 'like', "%{$q}%")
                        ->orWhere('dominio', 'like', "%{$q}%");
            });
        }

        // Se per_page for -1, retorna todos sem paginação
        if ($perPage == -1) {
            return response()->json($query->orderBy('nome')->get());
        }

        $perPage = (int) ($perPage ?: 10);
        $perPage = max(5, min($perPage, 100)); // Aumentei o limite maximo para 100

        $result = $query->orderBy('nome')->paginate($perPage);
        return response()->json($result);
    }

    public function show($id)
    {
        return response()->json(Prefeitura::findOrFail($id));
    }

    public function store(Request $request)
    {
        try {
            $validated = $request->validate([
                'nome' => 'required|string|max:255',
                'slug' => ['required', 'string', 'max:255', 'regex:/^[a-z0-9-]+$/', Rule::unique('prefeituras')->whereNull('deleted_at')],
                'dominio' => ['nullable', 'string', 'max:255', Rule::unique('prefeituras')->whereNull('deleted_at')],
                'cor_primaria' => 'required|string|max:7',
                'ativo' => 'boolean',
                'logo' => 'nullable|file|image|max:2048',
                'admin_email' => 'required|email|unique:users,email',
                'admin_password' => 'required|string|min:6',
            ]);

            $data = [
                'nome' => $validated['nome'],
                'slug' => Str::lower(Str::slug($validated['slug'], '-')),
                'dominio' => $validated['dominio'] ?? null,
                'cor_primaria' => $validated['cor_primaria'],
                'ativo' => $request->boolean('ativo', true),
            ];

            // Cria a prefeitura primeiro para ter o ID
            $prefeitura = Prefeitura::create($data);

            // Se tiver logo, faz upload usando o ID da prefeitura recém criada
            if ($request->hasFile('logo')) {
                // Salva em 'tenants/{id}/assets'
                $path = $this->fileService->storeFile($request->file('logo'), 'assets', (string) $prefeitura->id);
                
                // Atualiza a prefeitura com o path do logo
                $prefeitura->update(['logo' => $path]);
            }

            // Criar usuário admin para essa prefeitura
            $admin = new User();
            $admin->prefeitura_id = $prefeitura->id;
            $admin->name = 'Admin ' . $prefeitura->nome;
            $admin->email = $validated['admin_email'];
            $admin->password = Hash::make($validated['admin_password']);
            $admin->perfil = 'ADMIN';
            $admin->status = 'ATIVO';
            $admin->cpf = preg_replace('/[^0-9]/', '', microtime(true)); // CPF fake temporário
            $admin->save();

            return response()->json($prefeitura, 201);
        } catch (\Illuminate\Validation\ValidationException $e) {
            throw $e;
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Log::error('Erro ao criar prefeitura: ' . $e->getMessage());
            return response()->json(['message' => 'Erro interno ao criar prefeitura: ' . $e->getMessage()], 500);
        }
    }

    public function update(Request $request, $id)
    {
        try {
            $prefeitura = Prefeitura::findOrFail($id);

            $validated = $request->validate([
                'nome' => 'string|max:255',
                'slug' => ['string', 'max:255', 'regex:/^[a-z0-9-]+$/', Rule::unique('prefeituras')->ignore($prefeitura->id)->whereNull('deleted_at')],
                'dominio' => ['nullable', 'string', 'max:255', Rule::unique('prefeituras')->ignore($prefeitura->id)->whereNull('deleted_at')],
                'cor_primaria' => 'string|regex:/^#[0-9A-Fa-f]{3}(?:[0-9A-Fa-f]{3})?$/',
                'ativo' => 'boolean',
                'logo' => 'nullable|file|image|max:2048',
            ]);

            if (isset($validated['slug'])) {
                $validated['slug'] = Str::lower(Str::slug($validated['slug'], '-'));
            }

            if ($request->hasFile('logo')) {
                $path = $this->fileService->storeFile($request->file('logo'), 'assets', (string) $prefeitura->id);
                $validated['logo'] = $path;
            }
            
            // Garantir cast correto para boolean se vier string "0" ou "1"
            if ($request->has('ativo')) {
                $validated['ativo'] = $request->boolean('ativo');
            }

            $prefeitura->update($validated);

            return response()->json($prefeitura);
        } catch (\Illuminate\Validation\ValidationException $e) {
            throw $e;
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Log::error('Erro ao atualizar prefeitura: ' . $e->getMessage());
            return response()->json(['message' => 'Erro interno ao atualizar prefeitura: ' . $e->getMessage()], 500);
        }
    }

    public function destroy($id)
    {
        $prefeitura = Prefeitura::findOrFail($id);
        $prefeitura->delete();

        return response()->json(['message' => 'Prefeitura deletada com sucesso']);
    }
}
