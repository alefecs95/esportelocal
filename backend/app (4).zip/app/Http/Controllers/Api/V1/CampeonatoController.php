<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Services\CampeonatoService;
use App\Http\Requests\StoreCampeonatoRequest;
use App\Http\Requests\UpdateCampeonatoRequest;
use App\Enums\FormatoCampeonato;
use App\Services\WhatsAppNotificationService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CampeonatoController extends Controller
{
    protected $campeonatoService;

    public function __construct(
        CampeonatoService $campeonatoService,
        private WhatsAppNotificationService $whatsAppNotificationService
    ) {
        $this->campeonatoService = $campeonatoService;
    }

    private function response(bool $success, string $message, $data = [], int $status = 200): JsonResponse
    {
        return response()->json([
            'success' => $success,
            'message' => $message,
            'data' => $data,
        ], $status);
    }

    /**
     * Retorna os formatos de campeonato disponíveis (Enum)
     */
    public function getFormatos(): JsonResponse
    {
        return response()->json(FormatoCampeonato::toArray());
    }

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request): JsonResponse
    {
        $filters = $request->only(['modalidade_id', 'status', 'categoria', 'data_inicio', 'data_fim', 'temporada_id']);
        $perPage = $request->get('per_page', 10);
        
        $campeonatos = $this->campeonatoService->getAll($filters, $perPage);
        
        return $this->response(true, 'Campeonatos listados com sucesso', $campeonatos);
    }

    public function indexPublic(Request $request): JsonResponse
    {
        $filters = $request->only([
            'modalidade_id', 
            'temporada_id', 
            'status', 
            'categoria', 
            'cidade',
            'bairro'
        ]);
        
        $query = \App\Models\Campeonato::with(['modalidade', 'temporada'])
            ->where('status', '!=', 'cancelado');

        if (!empty($filters['modalidade_id'])) {
            $query->where('modalidade_id', $filters['modalidade_id']);
        }

        if (!empty($filters['temporada_id'])) {
            $query->where('temporada_id', $filters['temporada_id']);
        }

        if (!empty($filters['status'])) {
            $query->where('status', $filters['status']);
        }

        if (!empty($filters['categoria'])) {
            $query->where('categoria', 'like', '%' . $filters['categoria'] . '%');
        }

        if (!empty($filters['cidade'])) {
            $query->where('cidade_eleitoral', 'like', '%' . $filters['cidade'] . '%');
        }

        if (!empty($filters['bairro'])) {
            $query->where('bairro_eleitoral', 'like', '%' . $filters['bairro'] . '%');
        }

        // Ordenar por data de início decrescente (mais recentes primeiro)
        $campeonatos = $query->orderBy('data_inicio', 'desc')
            ->paginate($request->get('per_page', 12));
            
        return $this->response(true, 'Campeonatos listados com sucesso', $campeonatos);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreCampeonatoRequest $request): JsonResponse
    {
        try {
            $campeonato = $this->campeonatoService->create($request->validated());
            if ($campeonato->status === 'inscricoes_abertas') {
                $this->whatsAppNotificationService->notifyCompetitionCreated($campeonato);
            }
            return $this->response(true, 'Campeonato criado com sucesso', $campeonato, 201);
        } catch (\Exception $e) {
            return $this->response(false, 'Erro ao criar campeonato: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id): JsonResponse
    {
        try {
            $campeonato = $this->campeonatoService->find($id);
            return $this->response(true, 'Campeonato encontrado com sucesso', $campeonato);
        } catch (\Exception $e) {
            return $this->response(false, 'Campeonato não encontrado', [], 404);
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateCampeonatoRequest $request, string $id): JsonResponse
    {
        try {
            $statusAnterior = $this->campeonatoService->find($id)->status;
            $campeonato = $this->campeonatoService->update($id, $request->validated());
            if ($statusAnterior !== 'inscricoes_abertas' && $campeonato->status === 'inscricoes_abertas') {
                $this->whatsAppNotificationService->notifyCompetitionCreated($campeonato);
            }
            return $this->response(true, 'Campeonato atualizado com sucesso', $campeonato);
        } catch (\Exception $e) {
            return $this->response(false, 'Erro ao atualizar campeonato: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id): JsonResponse
    {
        try {
            $this->campeonatoService->delete($id);
            return $this->response(true, 'Campeonato excluído com sucesso');
        } catch (\Exception $e) {
            return $this->response(false, 'Erro ao excluir campeonato: ' . $e->getMessage(), [], 500);
        }
    }

    public function simularElegibilidade(Request $request)
    {
        $request->validate([
            'atleta_id' => 'required|exists:atletas,id',
            'campeonato_id' => 'required|exists:campeonatos,id',
        ]);

        $resultado = $this->campeonatoService->verificarElegibilidade(
            $request->atleta_id,
            $request->campeonato_id
        );

        return response()->json($resultado);
    }
}
