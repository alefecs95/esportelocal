<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Categoria;
use Illuminate\Http\Request;

class CategoriaController extends Controller
{
    public function index()
    {
        return response()->json(Categoria::orderBy('nome')->get());
    }

    public function store(Request $request)
    {
        $request->validate([
            'nome' => 'required|string|max:255',
            'cor' => 'nullable|string|max:7',
        ]);

        $slug = \Illuminate\Support\Str::slug($request->nome);
        
        $categoria = Categoria::create([
            'nome' => $request->nome,
            'slug' => $slug,
            'cor' => $request->cor ?? '#3b82f6', // Default blue
            'descricao' => $request->descricao
        ]);

        return response()->json($categoria, 201);
    }
}
