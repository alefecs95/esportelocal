<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Atleta;
use App\Http\Requests\StoreAtletaRequest;
use App\Http\Requests\UpdateAtletaRequest;
use App\Models\User;
use App\Scopes\TenantScope;
use App\Services\AtletaService;
use App\Services\CpfService;
use App\Services\TseService;
use App\Services\WhatsAppNotificationService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

class AtletaController extends Controller
{
    protected $atletaService;

    public function __construct(
        AtletaService $atletaService,
        private CpfService $cpfService,
        private TseService $tseService,
        private WhatsAppNotificationService $whatsAppNotificationService
    ) {
        $this->atletaService = $atletaService;
    }

    private function response(bool $success, string $message, $data = [], int $status = 200): JsonResponse
    {
        return response()->json([
            'success' => $success,
            'message' => $message,
            'data' => $data,
        ], $status);
    }

    public function index(Request $request): JsonResponse
    {
        $perPage = (int) $request->query('per_page', 10);
        $search = $request->query('search');
        $filters = [
            'acesso_ativo' => $this->parseBooleanQuery($request->query('acesso_ativo')),
            'pode_participar_competicoes' => $this->parseBooleanQuery($request->query('pode_participar_competicoes')),
            'cidade' => $request->query('cidade'),
            'titulo_verificado' => $this->parseBooleanQuery($request->query('titulo_verificado')),
            'idade_min' => $request->query('idade_min'),
            'idade_max' => $request->query('idade_max'),
        ];
        $atletas = $this->atletaService->getAll($perPage, $search, $filters);
        return $this->response(true, 'Atletas listados com sucesso', $atletas);
    }

    public function updateStatus(Request $request, string $id): JsonResponse
    {
        $user = $request->user();
        if (!$user) {
            return $this->response(false, 'Não autorizado', [], 401);
        }

        $request->validate([
            'acesso_ativo' => 'required|boolean',
            'pode_participar_competicoes' => 'required|boolean',
        ]);

        $atleta = $this->atletaService->find($id);
        if (!$atleta) {
            return $this->response(false, 'Atleta não encontrado', [], 404);
        }

        $acessoAtivo = (bool) $request->boolean('acesso_ativo');
        $podeParticipar = (bool) $request->boolean('pode_participar_competicoes');

        $atleta = $this->atletaService->update((int) $id, [
            'acesso_ativo' => $acessoAtivo,
            'pode_participar_competicoes' => $podeParticipar,
        ]);

        $userAtleta = User::withoutGlobalScope(TenantScope::class)
            ->where('cpf', preg_replace('/[^0-9]/', '', $atleta->cpf))
            ->where('prefeitura_id', $atleta->prefeitura_id)
            ->first();

        if ($userAtleta) {
            $userAtleta->status = $acessoAtivo ? 'ATIVO' : 'INATIVO';
            $userAtleta->save();
        }

        return $this->response(true, 'Status do atleta atualizado com sucesso', $atleta);
    }

    public function store(StoreAtletaRequest $request): JsonResponse
    {
        try {
            $data = $request->validated();
            $receiveNotifications = (bool) ($data['receive_notifications'] ?? false);
            $phoneForNotification = $this->whatsAppNotificationService->normalizePhone($data['telefone'] ?? null);
            unset($data['receive_notifications']);

            $isPublicRegister = $request->user() === null;
            if ($isPublicRegister) {
                $data = $this->fillElectoralDataFromApi($data);
            }

            if ($receiveNotifications && !$phoneForNotification) {
                return $this->response(
                    false,
                    'Para enviar notificação WhatsApp, informe um telefone válido com DDD.',
                    [],
                    422
                );
            }

            // Processar arquivos
            // Espera-se que o frontend envie:
            // arquivos[0][file] = (binary)
            // arquivos[0][nome] = "Nome do documento"
            
            $arquivos = [];
            if ($request->has('arquivos')) {
                // Se vier como array de objetos (dependendo de como o frontend envia)
                // Vamos iterar manualmente para montar a estrutura correta para o Service
                foreach ($request->file('arquivos') ?? [] as $index => $file) {
                    // O nome pode vir em um array paralelo ou dentro da estrutura se for form-data complexo
                    // Simplificando: vamos assumir que o frontend envia 'nomes_arquivos' como array indexado igual
                    $nome = $request->input("nomes_arquivos.$index") ?? $file->getClientOriginalName();
                    
                    $arquivos[] = [
                        'file' => $file,
                        'nome' => $nome
                    ];
                }
            }
            
            $data['arquivos'] = $arquivos;

            $atleta = $this->atletaService->create($data);
            if ($receiveNotifications) {
                $this->whatsAppNotificationService->notifyUserRegistration($atleta);
            }
            return $this->response(true, 'Cadastro realizado com sucesso. Seu login é seu CPF e sua senha inicial são os 4 últimos dígitos do CPF. No primeiro acesso será obrigatória a troca de senha.', $atleta, 201);
        } catch (\Exception $e) {
            $status = str_contains($e->getMessage(), 'dados eleitorais')
                || str_contains($e->getMessage(), 'consulta de título')
                ? 422
                : 500;
            return $this->response(false, 'Erro ao cadastrar atleta: ' . $e->getMessage(), [], $status);
        }
    }

    public function show(string $id): JsonResponse
    {
        $atleta = $this->atletaService->find($id);
        if (!$atleta) {
            return $this->response(false, 'Atleta não encontrado', [], 404);
        }
        return $this->response(true, 'Atleta encontrado com sucesso', $atleta);
    }

    public function update(UpdateAtletaRequest $request, string $id): JsonResponse
    {
        try {
            $data = $request->validated();
            
            $arquivos = [];
            if ($request->has('arquivos')) {
                foreach ($request->file('arquivos') ?? [] as $index => $file) {
                    $nome = $request->input("nomes_arquivos.$index") ?? $file->getClientOriginalName();
                    $arquivos[] = [
                        'file' => $file,
                        'nome' => $nome
                    ];
                }
            }
            $data['arquivos'] = $arquivos;

            $atleta = $this->atletaService->update($id, $data);
            return $this->response(true, 'Atleta atualizado com sucesso', $atleta);
        } catch (\Exception $e) {
            return $this->response(false, 'Erro ao atualizar atleta: ' . $e->getMessage(), [], 500);
        }
    }

    public function destroy(string $id): JsonResponse
    {
        try {
            $this->atletaService->delete($id);
            return $this->response(true, 'Atleta removido com sucesso', []);
        } catch (\Exception $e) {
            return $this->response(false, 'Erro ao remover atleta: ' . $e->getMessage(), [], 500);
        }
    }

    public function consultarCpf(string $cpf): JsonResponse
    {
        try {
            $cpfLimpo = preg_replace('/[^0-9]/', '', $cpf);
            $atletaLocal = Atleta::where('cpf', $cpfLimpo)->first();

            if ($atletaLocal) {
                return $this->response(true, 'Atleta já cadastrado no sistema', $atletaLocal);
            }

            $dadosCpf = $this->cpfService->getCpfData($cpfLimpo);
            return $this->response(true, 'Dados consultados com sucesso', $this->mapCpfPayload($dadosCpf));
        } catch (\Exception $e) {
            Log::error('Erro ao consultar CPF', ['cpf' => $cpf, 'error' => $e->getMessage()]);
            $status = str_contains(mb_strtolower($e->getMessage(), 'UTF-8'), 'limite diário') ? 429 : 422;
            return $this->response(false, 'Erro ao consultar CPF: ' . $e->getMessage(), [], $status);
        }
    }

    public function consultarTitulo(Request $request): JsonResponse
    {
        try {
            $cpf = preg_replace('/\D/', '', (string) $request->input('cpf', ''));
            if ($cpf === '') {
                return $this->response(false, 'CPF é obrigatório para consulta do TSE.', [], 422);
            }

            $forceRefresh = $request->boolean('force_refresh', false);
            $resultado = $this->tseService->getTseData($cpf, $forceRefresh);
            return $this->response(true, 'Consulta realizada com sucesso', $resultado);
        } catch (\Exception $e) {
            Log::error('Erro ao consultar Título no Controller: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
            $status = str_contains(mb_strtolower($e->getMessage(), 'UTF-8'), 'limite diário') ? 429 : 422;
            return $this->response(false, 'Erro ao consultar Título: ' . $e->getMessage(), [], $status);
        }
    }

    public function revalidarTitulo(string $id): JsonResponse
    {
        try {
            $atleta = $this->atletaService->find((int) $id);
            if (!$atleta) {
                return $this->response(false, 'Atleta não encontrado.', [], 404);
            }

            $idade = Carbon::parse($atleta->data_nascimento)->age;
            if ($idade < 16) {
                return $this->response(false, 'Atleta menor de 16 anos não precisa de validação eleitoral.', [], 422);
            }

            try {
                $resultado = $this->tseService->getTseData((string) $atleta->cpf, true);
            } catch (\Throwable $e) {
                $this->atletaService->update((int) $id, ['titulo_verificado' => false]);
                return $this->response(false, $e->getMessage(), [], 422);
            }

            $retorno = $resultado['retorno'] ?? null;
            if (!$retorno) {
                $this->atletaService->update((int) $id, ['titulo_verificado' => false]);
                return $this->response(false, 'A API não retornou dados eleitorais para validação.', [], 422);
            }

            $updateData = $this->extractElectoralFieldsFromRetorno($retorno);
            $dadosCompletos = $this->isElectoralDataComplete($updateData);
            $updateData['titulo_verificado'] = $dadosCompletos;

            if (!$dadosCompletos) {
                $this->atletaService->update((int) $id, array_merge($updateData, ['titulo_verificado' => false]));
                return $this->response(false, 'A API não retornou todos os dados obrigatórios para validar o título.', [], 422);
            }

            $atletaAtualizado = $this->atletaService->update((int) $id, $updateData);
            return $this->response(true, 'Título validado com sucesso.', $atletaAtualizado);
        } catch (\Exception $e) {
            Log::error('Erro ao revalidar título', ['id' => $id, 'error' => $e->getMessage()]);
            return $this->response(false, 'Erro ao revalidar título: ' . $e->getMessage(), [], 500);
        }
    }

    private function parseBooleanQuery($value): ?bool
    {
        if ($value === null || $value === '') {
            return null;
        }

        if (in_array($value, [true, 'true', '1', 1, 'ATIVO', 'ativo'], true)) {
            return true;
        }

        if (in_array($value, [false, 'false', '0', 0, 'INATIVO', 'inativo'], true)) {
            return false;
        }

        return null;
    }

    private function fillElectoralDataFromApi(array $data): array
    {
        $data['titulo_verificado'] = false;

        $dataNascimento = $data['data_nascimento'] ?? null;
        if (!$dataNascimento) {
            return $data;
        }

        $idade = Carbon::parse($dataNascimento)->age;
        if ($idade < 16) {
            $data['titulo_verificado'] = true;
            return $data;
        }

        $cpf = preg_replace('/\D/', '', (string) ($data['cpf'] ?? ''));
        if ($cpf === '') {
            return $data;
        }

        try {
            $consulta = $this->tseService->getTseData($cpf, false);
        } catch (\Throwable $e) {
            return $data;
        }

        $retorno = $consulta['retorno'] ?? null;
        if (!$retorno) {
            return $data;
        }

        $camposEleitorais = $this->extractElectoralFieldsFromRetorno($retorno);
        $data = array_merge($data, $camposEleitorais);
        $data['titulo_verificado'] = $this->isElectoralDataComplete($camposEleitorais);

        return $data;
    }

    private function mapCpfPayload(array $dados): array
    {
        return [
            'nome' => $dados['nome'] ?? '',
            'cpf' => $dados['cpf'] ?? '',
            'data_nascimento' => $dados['data_nascimento'] ?? null,
            'sexo' => $dados['sexo'] ?? '',
            'nome_mae' => '',
            'nome_pai' => '',
            'cep' => '',
            'endereco' => '',
            'bairro' => '',
            'cidade' => '',
            'estado' => '',
            'telefone' => '',
            'email' => '',
            'titulo_eleitor' => '',
            'zona_eleitoral' => '',
            'secao_eleitoral' => '',
        ];
    }

    private function extractElectoralFieldsFromRetorno(array $retorno): array
    {
        $domicilio = $retorno['domicilioEleitoral'] ?? [];
        $identificacao = $retorno['identificacao'] ?? [];

        return [
            'titulo_eleitor' => isset($identificacao['inscricao']) ? (string) $identificacao['inscricao'] : '',
            'zona_eleitoral' => isset($domicilio['zona']) ? trim((string) $domicilio['zona']) : '',
            'secao_eleitoral' => isset($domicilio['secao']) ? trim((string) $domicilio['secao']) : '',
            'bairro_eleitoral' => trim((string) ($domicilio['bairro'] ?? '')),
            'cidade_eleitoral' => trim((string) ($domicilio['municipio'] ?? '')),
            'uf_eleitoral' => strtoupper((string) ($domicilio['uf'] ?? '')),
        ];
    }

    private function isElectoralDataComplete(array $dados): bool
    {
        $obrigatorios = [
            $dados['zona_eleitoral'] ?? '',
            $dados['secao_eleitoral'] ?? '',
            $dados['bairro_eleitoral'] ?? '',
            $dados['cidade_eleitoral'] ?? '',
            $dados['uf_eleitoral'] ?? '',
        ];

        foreach ($obrigatorios as $valor) {
            if (trim((string) $valor) === '') {
                return false;
            }
        }

        return true;
    }
}
