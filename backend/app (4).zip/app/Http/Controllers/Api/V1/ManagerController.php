<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Campeonato;
use Illuminate\Http\Request;
use Carbon\Carbon;

class ManagerController extends Controller
{
    public function availableCampeonatos()
    {
        $hoje = Carbon::today();

        $campeonatos = Campeonato::where('status', 'inscricoes_abertas')
            ->where('tipo_competicao', 'equipe')
            ->where(function ($query) use ($hoje) {
                $query->whereNull('inicio_inscricao')
                    ->orWhereDate('inicio_inscricao', '<=', $hoje);
            })
            ->where(function ($query) use ($hoje) {
                $query->whereNull('fim_inscricao')
                    ->orWhereDate('fim_inscricao', '>=', $hoje);
            })
            ->with('modalidade')
            ->get();
            
        return response()->json($campeonatos);
    }
}
