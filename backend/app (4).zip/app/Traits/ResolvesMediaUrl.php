<?php

namespace App\Traits;

trait ResolvesMediaUrl
{
    protected function resolveMediaUrl(string $path): string
    {
        if (filter_var($path, FILTER_VALIDATE_URL)) {
            return $path;
        }

        $baseUrl = rtrim((string) config('app.url'), '/');
        if ($baseUrl === '') {
            $baseUrl = rtrim(url('/'), '/');
        }

        $basePath = rtrim((string) parse_url($baseUrl, PHP_URL_PATH), '/');
        $baseHasBackendPublic = $basePath !== '' && str_ends_with($basePath, '/backend/public');

        if (app()->isLocal() || $baseHasBackendPublic) {
            $mediaBasePath = '/api/v1/public/media';
        } else {
            $mediaBasePath = '/backend/public/api/v1/public/media';
        }

        $normalizedPath = ltrim($path, '/');
        $encodedPath = str_replace('%2F', '/', rawurlencode($normalizedPath));

        return $baseUrl . $mediaBasePath . '/' . $encodedPath;
    }
}
