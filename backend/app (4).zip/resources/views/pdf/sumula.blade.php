<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <style>
        @page {
            margin: 1cm;
        }
        body {
            font-family: Arial, sans-serif;
            font-size: 11px;
            color: #333;
        }
        .header {
            text-align: center;
            border-bottom: 2px solid #000;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        .header h1 {
            margin: 0;
            font-size: 18px;
            text-transform: uppercase;
        }
        .header h2 {
            margin: 5px 0;
            font-size: 14px;
            font-weight: normal;
        }
        .info-table {
            width: 100%;
            margin-bottom: 20px;
            border-collapse: collapse;
        }
        .info-table td {
            padding: 6px;
            border: 1px solid #ddd;
            vertical-align: top;
        }
        .teams-container {
            width: 100%;
            margin-bottom: 20px;
        }
        .team-box {
            width: 48%;
            float: left;
        }
        .team-box.right {
            float: right;
        }
        .team-header {
            background-color: #f3f4f6;
            padding: 6px;
            font-weight: bold;
            text-align: center;
            border: 1px solid #000;
            text-transform: uppercase;
            letter-spacing: 0.4px;
        }
        .player-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 10px;
        }
        .player-table th, .player-table td {
            border: 1px solid #ccc;
            padding: 3px 4px;
        }
        .player-table th {
            background-color: #f9f9f9;
            font-size: 9px;
            text-transform: uppercase;
        }
        .footer-signatures {
            margin-top: 50px;
            width: 100%;
            text-align: center;
        }
        .signature-box {
            display: inline-block;
            width: 31%;
            border-top: 1px solid #000;
            margin: 0 6px;
            padding-top: 5px;
        }
        .score-box {
            font-size: 24px;
            font-weight: bold;
            text-align: center;
            padding: 10px;
            border: 2px solid #000;
            margin: 20px 0;
            width: 150px;
            margin-left: auto;
            margin-right: auto;
        }
        .clearfix::after {
            content: "";
            clear: both;
            display: table;
        }
        .legend {
            font-size: 9px;
            color: #4b5563;
            margin: 8px 0 0;
            text-align: center;
        }
        .section-note {
            border: 1px solid #000;
            padding: 10px;
            margin-top: 16px;
            height: 72px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Súmula de Partida</h1>
        <h2>{{ $campeonato->nome }} - {{ $partida->fase->nome }}</h2>
    </div>

    <table class="info-table">
        <tr>
            <td><strong>Data/Hora:</strong> {{ $data_jogo }}</td>
            <td><strong>Local:</strong> {{ $partida->local }}</td>
            <td><strong>Rodada:</strong> {{ $partida->rodada }}ª</td>
        </tr>
        <tr>
            <td colspan="3"><strong>Árbitro:</strong> {{ $partida->arbitro ? $partida->arbitro->name : 'Não designado' }}</td>
        </tr>
    </table>

    <div class="score-box">
        {{ $partida->placar_mandante ?? ' ' }} X {{ $partida->placar_visitante ?? ' ' }}
    </div>
    <div class="legend">
        Sit: TIT = Titular, RES = Reserva | Cap: CAP = Capitão
    </div>

    <div class="teams-container clearfix">
        <div class="team-box">
            <div class="team-header">{{ $partida->mandante_equipe ? $partida->mandante_equipe->nome : 'Mandante' }}</div>
            <table class="player-table">
                <thead>
                    <tr>
                        <th width="10%">Nº</th>
                        <th width="10%">Sit</th>
                        <th width="10%">Cap</th>
                        <th>Nome do Atleta</th>
                        <th width="15%">Doc</th>
                        <th width="10%">Gol</th>
                        <th width="10%">CA</th>
                        <th width="10%">CV</th>
                    </tr>
                </thead>
                <tbody>
                    @if($partida->mandante_equipe && $partida->mandante_equipe->atletas)
                        @foreach($partida->mandante_equipe->atletas as $atleta)
                        <tr>
                            <td></td>
                            <td>{{ $atleta->escala_tipo ?? '' }}</td>
                            <td>{{ !empty($atleta->escala_capitao) ? 'CAP' : '' }}</td>
                            <td>{{ Str::limit($atleta->nome, 20) }}</td>
                            <td>{{ Str::limit($atleta->cpf, 11) }}</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        @endforeach
                        @for($i = 0; $i < (20 - $partida->mandante_equipe->atletas->count()); $i++)
                        <tr>
                            <td>&nbsp;</td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        @endfor
                    @else
                        <tr><td colspan="8" style="text-align:center">Sem atletas cadastrados</td></tr>
                    @endif
                </tbody>
            </table>
            <div style="margin-top:10px; border:1px solid #ccc; height:40px; padding:5px;">
                <strong>Técnico:</strong>
            </div>
        </div>

        <div class="team-box right">
            <div class="team-header">{{ $partida->visitante_equipe ? $partida->visitante_equipe->nome : 'Visitante' }}</div>
            <table class="player-table">
                <thead>
                    <tr>
                        <th width="10%">Nº</th>
                        <th width="10%">Sit</th>
                        <th width="10%">Cap</th>
                        <th>Nome do Atleta</th>
                        <th width="15%">Doc</th>
                        <th width="10%">Gol</th>
                        <th width="10%">CA</th>
                        <th width="10%">CV</th>
                    </tr>
                </thead>
                <tbody>
                    @if($partida->visitante_equipe && $partida->visitante_equipe->atletas)
                        @foreach($partida->visitante_equipe->atletas as $atleta)
                        <tr>
                            <td></td>
                            <td>{{ $atleta->escala_tipo ?? '' }}</td>
                            <td>{{ !empty($atleta->escala_capitao) ? 'CAP' : '' }}</td>
                            <td>{{ Str::limit($atleta->nome, 20) }}</td>
                            <td>{{ Str::limit($atleta->cpf, 11) }}</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        @endforeach
                        @for($i = 0; $i < (20 - $partida->visitante_equipe->atletas->count()); $i++)
                        <tr>
                            <td>&nbsp;</td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        @endfor
                    @else
                        <tr><td colspan="8" style="text-align:center">Sem atletas cadastrados</td></tr>
                    @endif
                </tbody>
            </table>
            <div style="margin-top:10px; border:1px solid #ccc; height:40px; padding:5px;">
                <strong>Técnico:</strong>
            </div>
        </div>
    </div>

    <div class="section-note">
        <strong>Observações do Árbitro:</strong>
    </div>

    <div class="footer-signatures">
        <div class="signature-box">
            @if($partida->assinatura_mandante)
                <img src="{{ $partida->assinatura_mandante }}" style="max-height: 50px; display: block; margin: 0 auto;">
            @else
                <br><br>
            @endif
            Capitão Mandante
        </div>
        <div class="signature-box">
            @if($partida->assinatura_arbitro)
                <img src="{{ $partida->assinatura_arbitro }}" style="max-height: 50px; display: block; margin: 0 auto;">
            @else
                <br><br>
            @endif
            Árbitro
        </div>
        <div class="signature-box">
            @if($partida->assinatura_visitante)
                <img src="{{ $partida->assinatura_visitante }}" style="max-height: 50px; display: block; margin: 0 auto;">
            @else
                <br><br>
            @endif
            Capitão Visitante
        </div>
    </div>
</body>
</html>
