<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Prefeitura;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;

class TenantController extends Controller
{
    public function show(Request $request)
    {
        if (!App::has('current_tenant')) {
            return response()->json(['message' => 'Nenhum tenant identificado.'], 404);
        }

        $tenant = App::get('current_tenant');
        if (!$tenant instanceof Prefeitura && isset($tenant->id)) {
            $tenant = Prefeitura::withoutGlobalScopes()->find($tenant->id);
        }

        if (!$tenant instanceof Prefeitura) {
            return response()->json(['message' => 'Nenhum tenant identificado.'], 404);
        }

        try {
            $logoUrl = $tenant->logo_url;
        } catch (\Throwable $e) {
            $logoUrl = null;
        }

        try {
            $bannerPortalUrl = $tenant->banner_portal_url;
        } catch (\Throwable $e) {
            $bannerPortalUrl = null;
        }

        try {
            $fundoLoginUrl = $tenant->fundo_login_url;
        } catch (\Throwable $e) {
            $fundoLoginUrl = null;
        }

        return response()->json([
            'id' => $tenant->id,
            'nome' => $tenant->nome,
            'slug' => $tenant->slug,
            'dominio' => $tenant->dominio,
            'cor_primaria' => $tenant->cor_primaria,
            'cor_secundaria' => $tenant->cor_secundaria,
            'logo' => is_string($tenant->logo) ? $tenant->logo : null,
            'banner_portal' => is_string($tenant->banner_portal) ? $tenant->banner_portal : null,
            'fundo_login' => is_string($tenant->fundo_login) ? $tenant->fundo_login : null,
            'logo_url' => is_string($logoUrl) ? $logoUrl : null,
            'banner_portal_url' => is_string($bannerPortalUrl) ? $bannerPortalUrl : null,
            'fundo_login_url' => is_string($fundoLoginUrl) ? $fundoLoginUrl : null,
            'ativo' => (bool) $tenant->ativo,
        ]);
    }
}
