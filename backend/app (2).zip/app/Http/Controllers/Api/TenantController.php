<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;

class TenantController extends Controller
{
    public function show(Request $request)
    {
        if (App::has('current_tenant')) {
            return response()->json(App::get('current_tenant'));
        }

        return response()->json(['message' => 'Nenhum tenant identificado.'], 404);
    }
}
