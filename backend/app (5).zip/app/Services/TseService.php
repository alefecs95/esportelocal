<?php

namespace App\Services;

use App\Models\ConsultaHistorico;
use App\Models\TseCache;
use Carbon\Carbon;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use RuntimeException;

class TseService
{
    public function getTseData(string $cpf, bool $forceRefresh = false): array
    {
        $cpfLimpo = $this->sanitizeCpf($cpf);

        try {
            if (!$this->isValidCpf($cpfLimpo)) {
                throw new RuntimeException('CPF inválido para consulta eleitoral.');
            }

            if (!$forceRefresh) {
                $cache = $this->getValidCache($cpfLimpo);
                if ($cache) {
                    $payload = $cache->dados_json ?? [];
                    $this->registerHistory('tse', $cpfLimpo, 'sucesso', 'cache', null, [
                        'source' => 'cache',
                        'force_refresh' => $forceRefresh,
                    ]);
                    return $payload;
                }
            }

            $source = 'api';
            $payload = $this->runWithLock($cpfLimpo, function () use ($cpfLimpo, $forceRefresh, &$source) {
                if (!$forceRefresh) {
                    $cache = $this->getValidCache($cpfLimpo);
                    if ($cache) {
                        $source = 'cache';
                        return $cache->dados_json ?? [];
                    }
                }

                $this->assertTenantQuota('tse');
                $apiData = $this->consultarApiTse($cpfLimpo);

                if (!$this->isComplete($apiData)) {
                    throw new RuntimeException('A API do TSE retornou dados incompletos.');
                }

                $agora = Carbon::now();
                TseCache::query()->updateOrCreate(
                    ['cpf' => $cpfLimpo],
                    [
                        'dados_json' => $apiData,
                        'consultado_em' => $agora,
                        'expira_em' => $agora->copy()->addDays(30),
                    ]
                );

                $source = 'api';
                return $apiData;
            });

            $this->registerHistory('tse', $cpfLimpo, 'sucesso', $source, null, [
                'source' => $source,
                'force_refresh' => $forceRefresh,
            ]);

            return $payload;
        } catch (\Throwable $e) {
            $this->registerHistory('tse', $cpfLimpo, 'erro', null, $e->getMessage(), [
                'force_refresh' => $forceRefresh,
            ]);
            if ($e instanceof RuntimeException) {
                throw $e;
            }
            throw new RuntimeException('Falha ao consultar TSE.');
        }
    }

    private function getValidCache(string $cpf): ?TseCache
    {
        return TseCache::query()
            ->where('cpf', $cpf)
            ->where('expira_em', '>', Carbon::now())
            ->first();
    }

    private function consultarApiTse(string $cpf): array
    {
        $url = env('DIRECTD_API_TSE_URL');
        $token = env('DIRECTD_API_TOKEN');

        if (!$url || !$token) {
            throw new RuntimeException('API de TSE não configurada.');
        }

        try {
            $response = Http::connectTimeout(8)->timeout(20)->get($url, [
                'TOKEN' => $token,
                'CPF' => $cpf,
            ]);
        } catch (\Throwable $e) {
            Log::error('Falha na consulta ao TSE', ['cpf' => $cpf, 'error' => $e->getMessage()]);
            throw new RuntimeException('Falha de comunicação com a API do TSE.');
        }

        if (!$response->successful()) {
            Log::error('Erro HTTP na API do TSE', ['cpf' => $cpf, 'status' => $response->status(), 'body' => $response->body()]);
            throw new RuntimeException('API do TSE indisponível no momento.');
        }

        $data = $response->json();
        if (!is_array($data)) {
            throw new RuntimeException('Resposta inválida da API do TSE.');
        }

        $resultadoId = (int) ($data['metaDados']['resultadoId'] ?? 1);
        if ($resultadoId !== 1) {
            $mensagem = (string) ($data['metaDados']['mensagem'] ?? 'Consulta eleitoral sem sucesso.');
            throw new RuntimeException($mensagem);
        }

        return $data;
    }

    private function isComplete(array $apiData): bool
    {
        $retorno = is_array($apiData['retorno'] ?? null) ? $apiData['retorno'] : [];
        $domicilio = is_array($retorno['domicilioEleitoral'] ?? null) ? $retorno['domicilioEleitoral'] : [];
        $identificacao = is_array($retorno['identificacao'] ?? null) ? $retorno['identificacao'] : [];

        $required = [
            trim((string) ($identificacao['inscricao'] ?? '')),
            trim((string) ($domicilio['zona'] ?? '')),
            trim((string) ($domicilio['secao'] ?? '')),
            trim((string) ($domicilio['bairro'] ?? '')),
            trim((string) ($domicilio['municipio'] ?? '')),
            strtoupper(trim((string) ($domicilio['uf'] ?? ''))),
        ];

        foreach ($required as $value) {
            if ($value === '') {
                return false;
            }
        }

        return true;
    }

    private function sanitizeCpf(string $cpf): string
    {
        return preg_replace('/\D/', '', $cpf) ?? '';
    }

    private function isValidCpf(string $cpf): bool
    {
        if (strlen($cpf) !== 11 || preg_match('/^(\d)\1{10}$/', $cpf) === 1) {
            return false;
        }

        for ($t = 9; $t < 11; $t++) {
            $sum = 0;
            for ($c = 0; $c < $t; $c++) {
                $sum += (int) $cpf[$c] * (($t + 1) - $c);
            }
            $digit = ((10 * $sum) % 11) % 10;
            if ((int) $cpf[$t] !== $digit) {
                return false;
            }
        }

        return true;
    }

    private function runWithLock(string $cpf, callable $callback): array
    {
        $store = Cache::getStore();
        if (method_exists($store, 'lock')) {
            return Cache::lock('tse-cache:' . $cpf, 10)->block(5, $callback);
        }

        return $callback();
    }

    private function assertTenantQuota(string $tipo): void
    {
        [$tenantId, $limit] = $this->resolveTenantAndLimit($tipo);

        if ($limit <= 0 || $tenantId <= 0) {
            return;
        }

        $key = 'consulta-limit:' . $tipo . ':' . $tenantId . ':' . now()->format('Ymd');
        $used = Cache::increment($key);
        if ($used === 1) {
            Cache::put($key, 1, now()->endOfDay());
        }

        if ($used > $limit) {
            throw new RuntimeException('Limite diário de consultas do tenant atingido.');
        }
    }

    private function resolveTenantAndLimit(string $tipo): array
    {
        if (!App::has('current_tenant')) {
            return [0, 0];
        }

        $tenant = App::get('current_tenant');
        $tenantId = (int) ($tenant->id ?? 0);

        $integracoes = is_array($tenant->configuracoes_integracoes ?? null) ? $tenant->configuracoes_integracoes : [];
        $consultas = is_array($integracoes['consultas'] ?? null) ? $integracoes['consultas'] : [];

        $limiteTipoTenant = (int) ($consultas['limite_diario_' . $tipo] ?? 0);
        $limiteTenant = (int) ($consultas['limite_diario'] ?? 0);
        $limiteTipoGlobal = (int) config('services.consultas.max_consultas_diarias_' . $tipo, 0);
        $limiteGlobal = (int) config('services.consultas.max_consultas_diarias_por_tenant', 0);

        $limite = $limiteTipoTenant > 0
            ? $limiteTipoTenant
            : ($limiteTenant > 0
                ? $limiteTenant
                : ($limiteTipoGlobal > 0 ? $limiteTipoGlobal : $limiteGlobal));

        return [$tenantId, $limite];
    }

    private function registerHistory(string $tipo, string $cpf, string $status, ?string $origem = null, ?string $mensagem = null, array $meta = []): void
    {
        [$tenantId] = $this->resolveTenantAndLimit($tipo);
        if ($tenantId <= 0) {
            return;
        }

        ConsultaHistorico::query()->create([
            'prefeitura_id' => $tenantId,
            'tipo' => $tipo,
            'status' => $status,
            'origem' => $origem,
            'cpf_consultado' => $this->maskCpf($cpf),
            'cpf_hash' => hash('sha256', $cpf),
            'mensagem' => $mensagem,
            'meta' => empty($meta) ? null : $meta,
            'consultado_em' => now(),
        ]);
    }

    private function maskCpf(string $cpf): string
    {
        $digits = $this->sanitizeCpf($cpf);
        if (strlen($digits) !== 11) {
            return $digits;
        }

        return substr($digits, 0, 3) . '.***.***-' . substr($digits, -2);
    }
}
